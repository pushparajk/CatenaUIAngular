import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TreeviewItem, TreeviewConfig } from 'ngx-treeview';
import { ReportsService } from './services/reports.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {

      items: TreeviewItem[];
      values: number[];
      config = TreeviewConfig.create({
      hasAllCheckBox: true,
      hasFilter: true,
      hasCollapseExpand: true,
      decoupleChildFromParent: false,
      maxHeight: 400
      });

    buttonClasses = [
    'btn-outline-primary',
    'btn-outline-secondary',
    'btn-outline-success',
    'btn-outline-danger',
    'btn-outline-warning',
    'btn-outline-info',
    'btn-outline-light',
    'btn-outline-dark'
    ];
    buttonClass = this.buttonClasses[0];

  constructor(private route: ActivatedRoute,private router: Router,private reportsService:ReportsService) { }

  ngOnInit(): void {
      this.items=this.reportsService.getBooks();
  }

  verify(){

    }

  onFilterChange(value: string): void {
    console.log('filter:', value);
  }
  goToDashboard(){
      this.router.navigate(['/dashboard']);
    }
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-schemelist',
  templateUrl: './schemelist.component.html',
  styleUrls: ['./schemelist.component.css']
})
export class SchemelistComponent implements OnInit {

  constructor(private route: ActivatedRoute,private router: Router) { }

  ngOnInit(): void {
  }

  goToAllocateFund(){
    this.router.navigate(['/allocatefund']);
  }

  goToDisbursement(){
    this.router.navigate(['/disbursement']);
  }

  goToDashboard(){
    this.router.navigate(['/dashboard']);
  }


}

import { Component, OnInit, Input, Output, EventEmitter  } from '@angular/core';
import { Donation } from './donation';
import { ActivatedRoute, Router } from '@angular/router';
import { DonationServiceService } from './services/donation-service.service';


@Component({
selector: 'app-donation',
templateUrl: './donation.component.html',
styleUrls: ['./donation.component.css']
})
export class DonationComponent implements OnInit {

donation1: Donation = new Donation();

constructor(private route: ActivatedRoute,private router: Router,private donationService: DonationServiceService) {
    //this.localDonation=donation;
  }

  get donation(): Donation{
      return this.donationService.donation;
  }

  set donation(localDonation: Donation){
       this.donationService.donation = localDonation;
  }


  save(): void {
    console.log('**** First Name = '+this.donation1.fName)
    this.donationService.save(this.donation1)
      .subscribe(data =>{
        console.log(data);
        this.goToConfiration();
        data.fName=this.donation1.fName;
        data.lName=this.donation1.lName;
        this.donationService.donation = data;
      },error => console.log('exception in save contract error = '+error));
  }

  ngOnInit(): void {
  }

  goToConfiration(){

    this.router.navigate(['/donationconfirm']);
  }

  goToDashboard(){
      this.router.navigate(['/home']);
    }


}


export class Fund {
  schemeName: string
  sanctionedAmount: number;
  allocateAmount: string;
  charityTrustId: number;
  centralAddress: string;
  stateId: string;
  returnedAmount: string;
  stateContractAddress: string;
}

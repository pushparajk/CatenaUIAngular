import { Component, OnInit } from '@angular/core';
import { Fund } from './fund';
import { ActivatedRoute, Router } from '@angular/router';
import { AllocatefundService } from './services/allocatefund.service';

@Component({
  selector: 'app-allocatefund',
  templateUrl: './allocatefund.component.html',
  styleUrls: ['./allocatefund.component.css']
})
export class AllocatefundComponent implements OnInit {
fund: Fund = new Fund();

  constructor(private route: ActivatedRoute,private router: Router,private allocatefundService: AllocatefundService) { }

  ngOnInit(): void {
  }

    save(): void {
    console.log('**** First Name = '+this.fund.allocateAmount)
    this.fund.centralAddress="0x2a314d4adfa695c4d63d8deec94e46305a76bd6f";
    this.fund.stateId="3";

    this.allocatefundService.save(this.fund)
      .subscribe(data =>{
        console.log(data);
        this.goToConfiration();
        this.allocatefundService.fund = data;
      },error => console.log('exception in save contract error = '+error));
  }


  goToDashboard(){
    this.router.navigate(['/dashboard']);
  }

  goToConfiration(){
    this.router.navigate(['/allocatefund2']);
  }


}

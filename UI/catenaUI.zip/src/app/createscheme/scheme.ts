export class Scheme {
  schemeName:string;
  schemeAmount: number;
  accountNumber: string;
  accountName: string;
  bankcode: string;
  schemeDetails: string;
  centralContractAddress: string;
  schemeBalanceAmount:number
}

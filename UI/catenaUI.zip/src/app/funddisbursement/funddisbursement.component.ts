import { Component, OnInit } from '@angular/core';
import { Disbursement } from './disbursement';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-funddisbursement',
  templateUrl: './funddisbursement.component.html',
  styleUrls: ['./funddisbursement.component.css']
})
export class FunddisbursementComponent implements OnInit {
disbursement: Disbursement = new Disbursement();

  constructor(private route: ActivatedRoute,private router: Router) { }

  ngOnInit(): void {
  }

  save(): void {
    }

  goToDashboard(){
    this.router.navigate(['/dashboard']);
  }



}

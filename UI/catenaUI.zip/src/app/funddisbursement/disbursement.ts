export class Disbursement {
  schemeName: string;
  charityTrustName: string;
  charityTrustId: number;
  allocatedAmount: number;
  balanceAmount: number;
  firstName: string;
  lastName: string;
  identificationNumber: string;
  disbursementAmount: number;
}
